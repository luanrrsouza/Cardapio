package com.example.cardapio;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class CardapioApplicationTests {

	@Test
	void contextLoads() {
	}

}
